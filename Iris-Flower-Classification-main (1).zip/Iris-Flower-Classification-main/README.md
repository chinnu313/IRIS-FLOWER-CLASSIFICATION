# Iris-Flower-Classification
"I developed a machine learning model to classify iris flowers into three species: Setosa, Versicolor, and Virginica. By leveraging algorithms like KNN, SVM, and Logistic Regression, I achieved high accuracy. This project gave me hands-on experience with Python, Scikit-learn, and data visualization techniques using Matplotlib and Seaborn."
